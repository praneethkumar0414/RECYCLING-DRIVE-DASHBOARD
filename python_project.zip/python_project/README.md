# Recycling Drive Dashboard

**Everyday Innovators - Project #47 | Environment & Sustainability**
Author: Thota Praneeth Kumar (26MVADSR0112) - Malla Reddy Vishwavidyapeeth - Technical Campus, CSE-AIDS

A beginner-friendly Python terminal app that tracks recyclable materials collected by category, validates every
input, saves data locally (JSON), and presents summaries, warnings, exports and Matplotlib charts.

## Quick start

```bash
cd python_project
python -m venv .venv
.venv\Scripts\activate          # Windows   (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt  # only Matplotlib is needed
python main.py
```

Requires Python 3.10+. Everything except charts uses the standard library only; if Matplotlib is missing, the app
still runs and option 7 explains how to install it.

Optional flags: `--data PATH` (use another data file), `--no-color` (plain output).

## Menu

| # | Feature | What it does |
|---|---|---|
| 1 | Add entry | Guided prompts with validation; `:q` cancels; asks to confirm anomalous (>150 kg) entries |
| 2 | View all | Fixed-width, paginated table (newest first) |
| 3 | Search / filter | Keyword, category, date range or weight range |
| 4 | Delete | By ID, with confirmation |
| 5 | Summary dashboard | Totals, averages, goal progress bar, status, 7-day trend, per-category bars, top collectors |
| 6 | Threshold warnings | Anomalies, duplicates, stale data, low/missing categories, deadline and pace alerts |
| 7 | Charts | PNGs: category bars, daily trend vs goal, distribution donut, combined dashboard |
| 8 | Export | Markdown report, plain-text audit log (with SHA-256), summary CSV and records CSV |
| 9 | Bulk CSV import | Format validation + row-by-row error log |
| 10 | Load sample data | 45 realistic entries (merge or replace) |

All output files go to `exports/`. Data lives in `data/records.json` (created automatically).

## Project layout

```
python_project/
  main.py                      entry point
  generate_sample_data.py      rebuilds the sample CSV/JSON (deterministic)
  requirements.txt  README.md  .gitignore
  recycling/
    config.py                  limits, categories, goal/deadline, thresholds (edit here)
    models.py                  Record dataclass
    validation.py              all input validators
    storage.py                 JSON persistence, schema checks, corrupted-file recovery
    analytics.py               totals, averages, trends, status, search, warnings
    charts.py                  Matplotlib charts
    reports.py                 Markdown / text / CSV exports
    importer.py                bulk CSV import
    ui.py                      ANSI styling, tables, pagination, prompts
    app.py                     menu loop and handlers
  data/
    sample_recycling.csv / .json        45 entries (normal, boundary, anomaly, edge cases)
    sample_import_with_errors.csv       14 rows with 9 deliberate errors for the import demo
  tests/test_core.py           21 unit tests
```

## Validation rules

- **Date**: `YYYY-MM-DD`, `DD-MM-YYYY` or `DD/MM/YYYY`; not before 2020-01-01; no future dates.
- **Category**: Paper, Plastic, Glass, Metal, Cardboard, E-Waste, Textile (case-insensitive; a few aliases).
- **Weight**: 0.1 - 500 kg; rejects blanks, text, negatives, NaN/inf; a `kg` suffix is accepted.
- **Collector**: 2-40 characters, letters/digits/spaces and `. , ' & -`.
- **Notes**: optional, max 120 characters, control characters stripped.

## Robustness

- Missing data file: a clean one is created. Corrupt or wrong-structure file: kept as `records.corrupt-<time>.json`
  and a clean file is started. Individual bad entries are skipped with a warning.
- Saves are atomic (temp file + replace), so a crash never leaves a half-written file.
- Ctrl+C / end of input exit cleanly; no input can crash the menu.
- CSV exports neutralise spreadsheet formula injection (cells starting with `= + - @`).

## Changing the goal or thresholds

Open `recycling/config.py` and edit `DRIVE_GOAL_KG`, `DRIVE_END_DATE`, `ANOMALY_WEIGHT_KG`, `CATEGORY_MIN_KG`, etc.

## Tests

```bash
python -m unittest discover -s tests -v
```

## Suggested 5-minute demo

1. Launch `python main.py` - show the branded welcome screen.
2. Option **10** to load sample data, then **1** to add an entry: type `tomorrow` as the date, `abc` / `-5` / `999`
   as the weight, and `200` to trigger the anomaly confirmation - validation catches each one.
3. Option **5** (summary), **6** (warnings), **3** (search).
4. Option **9** with `data/sample_import_with_errors.csv` - shows 5 imported, 9 rejected with reasons.
5. Option **7** then **8** - charts and exported reports appear in `exports/`.
6. Exit with **0**, relaunch, and run **5** again - the data is still there.

## Not included

The optional Tkinter / Textual GUI stretch feature was skipped; the terminal UI is fully featured and has no extra
dependencies.
