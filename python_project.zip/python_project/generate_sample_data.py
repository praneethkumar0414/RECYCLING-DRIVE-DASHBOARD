"""Regenerates data/sample_recycling.csv and .json (45 deterministic, realistic entries).

Run:  python generate_sample_data.py
Includes normal entries, boundary values (0.1 kg, exactly 150 kg), one anomalous entry,
notes containing commas/quotes, and a non-ASCII name.
"""
import csv
import json
import random
from datetime import date, timedelta
from pathlib import Path

DATA = Path(__file__).resolve().parent / "data"

COLLECTORS = ["Class 10A", "Eco Club", "Hostel Block B", "Canteen Team", "Library Staff", "Ananya R.", "Rahul K.",
              "Sneha's Team"]
RANGES = {  # typical kg range per category
    "Paper": (6, 28), "Plastic": (4, 22), "Glass": (5, 24), "Metal": (3, 18),
    "Cardboard": (8, 30), "E-Waste": (2, 12), "Textile": (1.5, 7),
}
WEIGHTS = {"Paper": 5, "Plastic": 6, "Glass": 3, "Metal": 3, "Cardboard": 5, "E-Waste": 2, "Textile": 1}
NOTES = ["", "", "", "Weekly bin pickup", "Sorted and cleaned", "Mixed - needs re-sorting", "Donated by staff",
         "Campus fest leftovers", 'Includes "bulk" bags, 3 sacks', "Collected after exams"]


def build():
    rng = random.Random(47)
    start = date(2026, 10, 25)
    cats = list(WEIGHTS)
    rows = []
    for i in range(40):
        day = start + timedelta(days=min(int(i * 29 / 39), 28))
        cat = rng.choices(cats, weights=[WEIGHTS[c] for c in cats])[0]
        low, high = RANGES[cat]
        rows.append({"date": day.isoformat(), "category": cat, "weight_kg": round(rng.uniform(low, high), 2),
                     "collector": rng.choice(COLLECTORS), "notes": rng.choice(NOTES)})
    rows += [  # hand-written edge cases
        {"date": "2026-10-27", "category": "E-Waste", "weight_kg": 0.1, "collector": "Library Staff",
         "notes": "Boundary: minimum weight (one phone charger)"},
        {"date": "2026-11-05", "category": "Cardboard", "weight_kg": 150.0, "collector": "Canteen Team",
         "notes": "Boundary: exactly at anomaly limit"},
        {"date": "2026-11-12", "category": "Plastic", "weight_kg": 185.5, "collector": "Eco Club",
         "notes": "Anomaly: whole-campus clean-up day, please verify"},
        {"date": "2026-11-14", "category": "Textile", "weight_kg": 6.2, "collector": "Ananya R.",
         "notes": "Old uniforms for the donation drive"},
        {"date": "2026-11-22", "category": "Glass", "weight_kg": 12.75, "collector": "Zoë D'Souza",
         "notes": "Non-ASCII name, latest entry"},
    ]
    rows.sort(key=lambda r: r["date"])
    for i, r in enumerate(rows, start=1):
        r["id"] = i
    return rows


def main():
    rows = build()
    DATA.mkdir(exist_ok=True)
    fields = ["id", "date", "category", "weight_kg", "collector", "notes"]
    with (DATA / "sample_recycling.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    payload = {"schema_version": 1, "records": [{k: r[k] for k in fields} for r in rows]}
    (DATA / "sample_recycling.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {len(rows)} entries, total {sum(r['weight_kg'] for r in rows):.2f} kg")


if __name__ == "__main__":
    main()
