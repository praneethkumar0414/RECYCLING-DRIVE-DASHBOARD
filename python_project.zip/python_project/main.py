#!/usr/bin/env python3
"""Recycling Drive Dashboard - entry point.

Run:  python main.py
"""
import sys

from recycling.app import main

if __name__ == "__main__":
    sys.exit(main())
