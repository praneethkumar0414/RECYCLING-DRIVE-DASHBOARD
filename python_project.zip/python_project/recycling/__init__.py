"""Recycling Drive Dashboard - track recyclables by category and visualise totals."""

__version__ = "1.0.0"
