"""Core business logic: totals by category, averages, trends, status and threshold warnings."""
from collections import defaultdict
from datetime import date, timedelta
from typing import NamedTuple

from .config import (
    ANOMALY_WEIGHT_KG, CATEGORIES, CATEGORY_MIN_KG, CRITICAL_STALE_DAYS, DRIVE_END_DATE,
    DRIVE_GOAL_KG, STALE_DAYS,
)
from .models import Record, dup_key


class Warn(NamedTuple):
    level: str    # "critical" | "warning" | "info"
    message: str


# ---- searching ---------------------------------------------------------------
def search(records, keyword=None, category=None, date_from=None, date_to=None,
           min_weight=None, max_weight=None) -> list[Record]:
    """Filter records. All supplied criteria must match; dates are ISO strings."""
    kw = keyword.strip().lower() if keyword else None
    out = []
    for r in records:
        if category and r.category != category:
            continue
        if date_from and r.date < date_from:
            continue
        if date_to and r.date > date_to:
            continue
        if min_weight is not None and r.weight_kg < min_weight:
            continue
        if max_weight is not None and r.weight_kg > max_weight:
            continue
        if kw and kw not in f"{r.collector} {r.notes} {r.category} {r.date}".lower():
            continue
        out.append(r)
    return out


# ---- aggregation ---------------------------------------------------------------
def total_kg(records) -> float:
    return round(sum(r.weight_kg for r in records), 2)


def by_category(records) -> list[dict]:
    """Totals for every known category (zero rows included), largest first."""
    sums: dict[str, float] = defaultdict(float)
    counts: dict[str, int] = defaultdict(int)
    for r in records:
        sums[r.category] += r.weight_kg
        counts[r.category] += 1
    total = sum(sums.values())
    names = list(CATEGORIES) + [c for c in sums if c not in CATEGORIES]
    rows = [{
        "category": c,
        "kg": round(sums[c], 2),
        "count": counts[c],
        "avg": round(sums[c] / counts[c], 2) if counts[c] else 0.0,
        "pct": round(100 * sums[c] / total, 1) if total else 0.0,
    } for c in names]
    return sorted(rows, key=lambda row: (-row["kg"], row["category"]))


def by_collector(records) -> list[dict]:
    sums: dict[str, float] = defaultdict(float)
    counts: dict[str, int] = defaultdict(int)
    for r in records:
        sums[r.collector] += r.weight_kg
        counts[r.collector] += 1
    rows = [{"collector": c, "kg": round(sums[c], 2), "count": counts[c]} for c in sums]
    return sorted(rows, key=lambda row: (-row["kg"], row["collector"]))


def daily_totals(records) -> dict[str, float]:
    sums: dict[str, float] = defaultdict(float)
    for r in records:
        sums[r.date] += r.weight_kg
    return {d: round(sums[d], 2) for d in sorted(sums)}


def cumulative(daily: dict[str, float]) -> list[float]:
    running, out = 0.0, []
    for d in daily:
        running += daily[d]
        out.append(round(running, 2))
    return out


def goal_status(total: float, goal: float = DRIVE_GOAL_KG) -> tuple[float, str, str]:
    """Return (percent of goal, label, level) where level is ok|warn|bad."""
    pct = round(100 * total / goal, 1) if goal else 0.0
    if pct >= 100:
        return pct, "GOAL REACHED", "ok"
    if pct >= 60:
        return pct, "ON TRACK", "ok"
    if pct >= 30:
        return pct, "BEHIND TARGET", "warn"
    return pct, "CRITICAL - FAR BELOW TARGET", "bad"


def weekly_trend(records) -> dict:
    """Compare the latest 7 days with the 7 days before (relative to the newest entry)."""
    if not records:
        return {"last7": 0.0, "prev7": 0.0, "change_pct": None, "direction": "no data"}
    newest = max(r.day for r in records)
    last_start = newest - timedelta(days=6)
    prev_start = newest - timedelta(days=13)
    last7 = sum(r.weight_kg for r in records if r.day >= last_start)
    prev7 = sum(r.weight_kg for r in records if prev_start <= r.day < last_start)
    if prev7 == 0:
        change, direction = None, "rising" if last7 > 0 else "steady"
    else:
        change = round(100 * (last7 - prev7) / prev7, 1)
        direction = "rising" if change > 5 else "falling" if change < -5 else "steady"
    return {"last7": round(last7, 2), "prev7": round(prev7, 2), "change_pct": change, "direction": direction}


def summarize(records, goal: float = DRIVE_GOAL_KG) -> dict:
    total = total_kg(records)
    pct, label, level = goal_status(total, goal)
    cats = by_category(records)
    days = daily_totals(records)
    top = next((c for c in cats if c["kg"] > 0), None)
    largest = max(records, key=lambda r: r.weight_kg, default=None)
    return {
        "entries": len(records),
        "total_kg": total,
        "avg_per_entry": round(total / len(records), 2) if records else 0.0,
        "avg_per_day": round(total / len(days), 2) if days else 0.0,
        "active_days": len(days),
        "first_date": min(days) if days else None,
        "last_date": max(days) if days else None,
        "goal_kg": goal,
        "goal_pct": pct,
        "status": label,
        "status_level": level,
        "remaining_kg": round(max(goal - total, 0), 2),
        "categories": cats,
        "top_category": top,
        "largest_entry": largest,
        "collectors": by_collector(records),
        "trend": weekly_trend(records),
    }


# ---- threshold warnings ----------------------------------------------------------
def find_warnings(records, today: date | None = None, goal: float = DRIVE_GOAL_KG,
                  end_date: date = DRIVE_END_DATE) -> list[Warn]:
    today = today or date.today()
    warns: list[Warn] = []
    if not records:
        return [Warn("info", "No entries recorded yet - add your first collection to get started.")]

    # anomalous entries
    for r in sorted(records, key=lambda x: -x.weight_kg):
        if r.weight_kg > ANOMALY_WEIGHT_KG:
            warns.append(Warn("warning", f"Anomalous entry #{r.id}: {r.weight_kg:g} kg of {r.category} on {r.date} "
                                         f"(limit {ANOMALY_WEIGHT_KG:g} kg) - please verify."))

    # duplicates
    seen: dict[tuple, int] = {}
    for r in records:
        key = dup_key(r.date, r.category, r.weight_kg, r.collector)
        if key in seen:
            warns.append(Warn("warning", f"Possible duplicate: #{r.id} matches #{seen[key]} "
                                         f"({r.date}, {r.category}, {r.weight_kg:g} kg, {r.collector})."))
        else:
            seen[key] = r.id

    # stale data
    newest = max(r.day for r in records)
    idle = (today - newest).days
    if idle >= CRITICAL_STALE_DAYS:
        warns.append(Warn("critical", f"No collections logged for {idle} days (last entry {newest.isoformat()})."))
    elif idle >= STALE_DAYS:
        warns.append(Warn("warning", f"No collections logged for {idle} days (last entry {newest.isoformat()})."))

    # weak categories
    for c in by_category(records):
        if c["kg"] == 0:
            warns.append(Warn("warning", f"No {c['category']} collected yet."))
        elif c["kg"] < CATEGORY_MIN_KG:
            warns.append(Warn("info", f"{c['category']} is low: {c['kg']:g} kg (minimum target {CATEGORY_MIN_KG:g} kg)."))

    # goal / deadline
    total = total_kg(records)
    remaining = goal - total
    days_left = (end_date - today).days
    if remaining <= 0:
        warns.append(Warn("info", f"Goal reached: {total:g} kg of {goal:g} kg collected."))
    elif days_left < 0:
        warns.append(Warn("critical", f"Drive deadline ({end_date.isoformat()}) has passed - "
                                      f"{remaining:g} kg short of the {goal:g} kg goal."))
    else:
        span = max((newest - min(r.day for r in records)).days + 1, 1)
        pace = total / span
        needed = remaining / max(days_left, 1)
        if needed > 2 * pace:
            warns.append(Warn("warning", f"Pace too slow: need {needed:.1f} kg/day for {days_left} more day(s), "
                                         f"current average is {pace:.1f} kg/day."))
        elif days_left <= 7:
            warns.append(Warn("info", f"Deadline in {days_left} day(s); {remaining:g} kg still to collect."))

    order = {"critical": 0, "warning": 1, "info": 2}
    return sorted(warns, key=lambda w: order[w.level])
