"""Menu-driven application loop connecting user actions to the backend modules."""
import argparse
from datetime import date

from . import analytics, charts, importer, reports, ui, validation
from .config import (
    ANOMALY_WEIGHT_KG, CATEGORIES, DATA_FILE, EXPORT_DIR, MAX_WEIGHT_KG, MIN_WEIGHT_KG,
    SAMPLE_BAD_CSV, SAMPLE_JSON,
)
from .storage import RecordStore

MENU = [
    ("1", "Add a collection entry"),
    ("2", "View all entries"),
    ("3", "Search / filter entries"),
    ("4", "Delete an entry"),
    ("5", "Summary dashboard"),
    ("6", "Threshold warnings"),
    ("7", "Generate charts (PNG)"),
    ("8", "Export reports (Markdown / audit log / CSV)"),
    ("9", "Bulk import from CSV"),
    ("10", "Load sample data"),
    ("0", "Exit"),
]

TABLE_HEAD = ["ID", "Date", "Category", "kg", "Collector", "Notes"]
TABLE_WIDTHS = [4, 10, 10, 8, 18, 26]
TABLE_ALIGN = ["<", "<", "<", ">", "<", "<"]


def _rows(records):
    ordered = sorted(records, key=lambda r: (r.date, r.id), reverse=True)
    return [[r.id, r.date, r.category, f"{r.weight_kg:g}", r.collector, r.notes] for r in ordered]


def _show(records):
    ui.print_table(TABLE_HEAD, _rows(records), TABLE_WIDTHS, TABLE_ALIGN)


# ---- handlers ----------------------------------------------------------------------
def add_entry(store):
    ui.heading("Add a collection entry   (type :q at any prompt to cancel)")
    day = ui.ask("Date (YYYY-MM-DD or DD-MM-YYYY)", validation.validate_date, default=date.today().isoformat())
    category = ui.ask_category(validation.validate_category)
    weight = ui.ask(f"Weight in kg ({MIN_WEIGHT_KG:g} - {MAX_WEIGHT_KG:g})", validation.validate_weight)
    if weight > ANOMALY_WEIGHT_KG:
        ui.warn(f"{weight:g} kg is unusually large (limit {ANOMALY_WEIGHT_KG:g} kg).")
        if not ui.confirm("Save this entry anyway?"):
            ui.info("Entry discarded.")
            return
    collector = ui.ask("Collector / class / team", validation.validate_collector)
    notes = ui.ask("Notes (optional, Enter to skip)", validation.validate_notes, default="")
    rec = store.add(day, category, weight, collector, notes)
    ui.ok(f"Saved entry #{rec.id}: {rec.weight_kg:g} kg of {rec.category} on {rec.date}.")


def view_all(store):
    ui.heading(f"All entries ({len(store.records)})")
    _show(store.records)


def search_entries(store):
    ui.heading("Search / filter entries")
    print("    1. Keyword (collector, notes, category, date)")
    print("    2. Category")
    print("    3. Date range")
    print("    4. Weight range")
    choice = ui.ask("Filter by", lambda raw: _one_of(raw, "1234"))
    if choice == "1":
        kw = ui.ask("Keyword", _non_blank)
        found = analytics.search(store.records, keyword=kw)
    elif choice == "2":
        cat = ui.ask_category(validation.validate_category)
        found = analytics.search(store.records, category=cat)
    elif choice == "3":
        start = ui.ask("From date", lambda v: validation.validate_date(v, allow_future=True))
        end = ui.ask("To date", lambda v: validation.validate_date(v, allow_future=True), default=date.today().isoformat())
        if start > end:
            start, end = end, start
        found = analytics.search(store.records, date_from=start, date_to=end)
    else:
        low = ui.ask("Minimum kg", validation.validate_weight, default=MIN_WEIGHT_KG)
        high = ui.ask("Maximum kg", validation.validate_weight, default=MAX_WEIGHT_KG)
        if low > high:
            low, high = high, low
        found = analytics.search(store.records, min_weight=low, max_weight=high)
    print()
    ui.info(f"{len(found)} match(es), {analytics.total_kg(found):g} kg in total")
    _show(found)


def delete_entry(store):
    ui.heading("Delete an entry")
    rec_id = ui.ask("Entry ID to delete", validation.validate_id)
    rec = store.get(rec_id)
    if rec is None:
        ui.err(f"No entry with ID {rec_id}.")
        return
    ui.info(f"#{rec.id}  {rec.date}  {rec.category}  {rec.weight_kg:g} kg  {rec.collector}")
    if ui.confirm("Permanently delete this entry?"):
        store.delete(rec_id)
        ui.ok(f"Entry #{rec_id} deleted.")
    else:
        ui.info("Nothing deleted.")


def show_summary(store):
    ui.heading("Summary dashboard")
    if not store.records:
        ui.info("No data yet. Add entries (1), import a CSV (9) or load the sample data (10).")
        return
    s = analytics.summarize(store.records)
    style = ui.LEVEL_STYLE[s["status_level"]]
    print(f"  Total collected : {ui.paint(str(s['total_kg']) + ' kg', 'bold', 'lavender')}   "
          f"({s['entries']} entries over {s['active_days']} active days)")
    print(f"  Averages        : {s['avg_per_entry']:g} kg per entry, {s['avg_per_day']:g} kg per active day")
    print(f"  Period          : {s['first_date']}  to  {s['last_date']}")
    print(f"  Goal progress   : {ui.progress_bar(s['goal_pct'])}  of {s['goal_kg']:g} kg")
    print(f"  Status          : {ui.paint(s['status'], 'bold', style)}   ({s['remaining_kg']:g} kg remaining)")
    t = s["trend"]
    change = "n/a" if t["change_pct"] is None else f"{t['change_pct']:+g}%"
    print(f"  7-day trend     : {t['direction']} ({change}); last 7 days {t['last7']:g} kg vs previous {t['prev7']:g} kg")
    if s["largest_entry"]:
        big = s["largest_entry"]
        print(f"  Largest entry   : #{big.id} - {big.weight_kg:g} kg of {big.category} ({big.date})")

    ui.heading("Totals by category")
    top = max(c["kg"] for c in s["categories"]) or 1
    rows = [[c["category"], c["count"], f"{c['kg']:g}", f"{c['avg']:g}", f"{c['pct']:g}%", ui.bar(c["kg"], top)]
            for c in s["categories"]]
    ui.print_table(["Category", "Entries", "Total kg", "Avg kg", "Share", "Distribution"], rows,
                   [10, 7, 9, 7, 6, 24], ["<", ">", ">", ">", ">", "<"])

    ui.heading("Top collectors")
    rows = [[c["collector"], c["count"], f"{c['kg']:g}"] for c in s["collectors"][:5]]
    ui.print_table(["Collector", "Entries", "Total kg"], rows, [24, 7, 9], ["<", ">", ">"])

    warns = analytics.find_warnings(store.records)
    serious = [w for w in warns if w.level != "info"]
    if serious:
        print()
        ui.warn(f"{len(serious)} warning(s) need attention - see option 6.")


def show_warnings(store):
    ui.heading("Threshold warnings")
    warns = analytics.find_warnings(store.records)
    tag = {"critical": "CRITICAL", "warning": "WARNING ", "info": "INFO    "}
    for w in warns:
        print(ui.paint(f"  [{tag[w.level]}] {w.message}", ui.LEVEL_STYLE[w.level]))
    if all(w.level == "info" for w in warns):
        ui.ok("No critical issues or warnings.")


def make_charts(store):
    ui.heading("Generate charts")
    try:
        paths = charts.generate_all(store.records)
    except charts.ChartError as exc:
        ui.err(str(exc))
        return
    EXPORT_DIR.mkdir(exist_ok=True)
    for p in paths:
        ui.ok(f"Saved {p}")
    if ui.confirm("Open the combined dashboard image now?"):
        if not ui.open_file(paths[-1]):
            ui.warn("Could not open an image viewer - open the file above manually.")


def export_reports(store):
    ui.heading("Export reports")
    if not store.records:
        ui.info("Nothing to export yet.")
        return
    for p in reports.export_all(store.records):
        ui.ok(f"Saved {p}")


def import_csv(store):
    ui.heading("Bulk import from CSV   (required columns: date, category, weight_kg, collector; optional: notes)")
    ui.info(f"Tip: try the bundled test file  {SAMPLE_BAD_CSV}")
    path = ui.ask("Path to CSV file", _non_blank)
    try:
        result = importer.import_csv(path, store)
    except importer.ImportFormatError as exc:
        ui.err(str(exc))
        return
    ui.ok(f"Imported {result.imported} of {result.total_rows} row(s).")
    if result.errors:
        ui.warn(f"{result.rejected} row(s) rejected:")
        for line in result.errors[:15]:
            print(ui.paint("    " + line, "yellow"))
        if result.rejected > 15:
            ui.info(f"... and {result.rejected - 15} more.")
        ui.info(f"Full error log: {result.log_path}")


def load_sample(store):
    ui.heading("Load sample data")
    replace = False
    if store.records:
        ui.info(f"You already have {len(store.records)} entries.")
        replace = ui.confirm("Replace them with the sample data? (No = merge, skipping duplicates)")
        if replace and not ui.confirm("This erases your current entries. Really replace?"):
            return
    added = store.load_sample(SAMPLE_JSON, replace=replace)
    ui.ok(f"Loaded {added} sample entr{'y' if added == 1 else 'ies'}.")


# ---- small validators -------------------------------------------------------------
def _non_blank(raw):
    if not raw.strip():
        raise validation.ValidationError("This cannot be blank.")
    return raw.strip()


def _one_of(raw, allowed):
    if len(raw) == 1 and raw in allowed:
        return raw
    raise validation.ValidationError(f"Please choose one of: {', '.join(allowed)}.")


HANDLERS = {
    "1": add_entry, "2": view_all, "3": search_entries, "4": delete_entry, "5": show_summary,
    "6": show_warnings, "7": make_charts, "8": export_reports, "9": import_csv, "10": load_sample,
}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Recycling Drive Dashboard")
    parser.add_argument("--data", default=str(DATA_FILE), help="path of the JSON data file")
    parser.add_argument("--no-color", action="store_true", help="disable ANSI colours")
    args = parser.parse_args(argv)

    ui.setup_terminal(no_color=args.no_color)
    ui.banner()
    store = RecordStore(args.data)
    try:
        store.load()
    except OSError as exc:
        ui.err(f"Cannot read or write the data file: {exc}")
        return 1
    for message in store.warnings:
        ui.warn(message)
    ui.info(f"{len(store.records)} entr{'y' if len(store.records) == 1 else 'ies'} loaded from {store.path}")

    try:
        while True:
            ui.heading("MAIN MENU")
            for key, label in MENU:
                print(f"   {ui.paint(key.rjust(2), 'bold', 'purple')}  {label}")
            try:
                choice = input(ui.paint("\n  Choose an option: ", "bold", "lavender")).strip()
            except EOFError:
                break
            if choice == "0":
                break
            handler = HANDLERS.get(choice)
            if handler is None:
                ui.err("Invalid choice - enter a number from the menu.")
                continue
            try:
                handler(store)
            except ui.Cancelled:
                ui.info("Cancelled.")
            except OSError as exc:
                ui.err(f"File problem: {exc}")
            ui.pause()
    except KeyboardInterrupt:
        print()
    ui.info("Data saved. Thank you for recycling!")
    return 0
