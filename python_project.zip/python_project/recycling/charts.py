"""Matplotlib charts: category totals, daily trend vs goal, distribution donut, combined dashboard."""
from datetime import datetime
from pathlib import Path

from .analytics import by_category, cumulative, daily_totals, goal_status, total_kg
from .config import APP_NAME, DRIVE_GOAL_KG, EXPORT_DIR

# Palette: charcoal / off-white / lavender / purple accent.
BG = "#FAF8FF"
INK = "#2B2B33"
MUTED = "#7A7790"
GRID = "#E4DFF5"
ACCENT = "#7C5CFF"
LAVENDER = "#C9B8FF"
CATEGORY_COLORS = {
    "Paper": "#7C5CFF", "Plastic": "#F2A93B", "Glass": "#2BB3A3", "Metal": "#8A94A6",
    "Cardboard": "#C98B5A", "E-Waste": "#E4572E", "Textile": "#E27BB4",
}


class ChartError(Exception):
    """Charts cannot be produced (matplotlib missing or no data)."""


def _plt():
    try:
        import matplotlib
        matplotlib.use("Agg")  # file output only; works on machines without a display
        import matplotlib.pyplot as plt
        return plt
    except ImportError:
        raise ChartError("Matplotlib is not installed. Run:  pip install matplotlib") from None


def _style(ax, title):
    ax.set_facecolor(BG)
    ax.set_title(title, loc="left", fontsize=12, fontweight="bold", color=INK, pad=10)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(GRID)
    ax.tick_params(colors=MUTED, labelsize=9)


def _color(name):
    return CATEGORY_COLORS.get(name, LAVENDER)


def draw_bars(ax, records):
    rows = [c for c in by_category(records)][::-1]  # largest on top
    names = [c["category"] for c in rows]
    vals = [c["kg"] for c in rows]
    bars = ax.barh(names, vals, color=[_color(n) for n in names], height=0.62)
    top = max(vals) if vals else 1
    for bar, v in zip(bars, vals):
        ax.text(v + top * 0.015, bar.get_y() + bar.get_height() / 2, f"{v:g} kg",
                va="center", fontsize=9, color=INK)
    ax.set_xlim(0, top * 1.18 or 1)
    ax.set_xlabel("Weight collected (kg)", color=MUTED, fontsize=9)
    ax.xaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    _style(ax, "Total collected by category")


def draw_trend(ax, records, goal=DRIVE_GOAL_KG):
    import matplotlib.dates as mdates
    daily = daily_totals(records)
    days = [datetime.strptime(d, "%Y-%m-%d") for d in daily]
    ax.bar(days, list(daily.values()), color=LAVENDER, width=0.8, label="Daily total")
    ax.set_ylabel("Daily kg", color=MUTED, fontsize=9)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax2 = ax.twinx()
    ax2.plot(days, cumulative(daily), color=ACCENT, linewidth=2.2, marker="o", markersize=3, label="Cumulative")
    ax2.axhline(goal, color=INK, linestyle="--", linewidth=1, label=f"Goal {goal:g} kg")
    ax2.set_ylim(0, max(goal, max(cumulative(daily), default=0)) * 1.08)
    ax2.set_ylabel("Cumulative kg", color=MUTED, fontsize=9)
    ax2.tick_params(colors=MUTED, labelsize=9)
    for side in ("top",):
        ax2.spines[side].set_visible(False)
    ax2.spines["right"].set_color(GRID)
    ax2.spines["left"].set_visible(False)
    ax2.spines["bottom"].set_visible(False)
    locator = mdates.AutoDateLocator()
    ax.xaxis.set_major_locator(locator)
    ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(locator))
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="lower right", bbox_to_anchor=(1.0, 1.0), ncol=3, frameon=False, fontsize=8)
    _style(ax, "Collection trend vs goal")


def draw_donut(ax, records):
    rows = [c for c in by_category(records) if c["kg"] > 0]
    ax.pie([c["kg"] for c in rows], colors=[_color(c["category"]) for c in rows], startangle=90,
           counterclock=False, wedgeprops={"width": 0.42, "edgecolor": BG, "linewidth": 2},
           autopct=lambda p: f"{p:.0f}%" if p >= 6 else "", pctdistance=0.79,
           textprops={"color": "white", "fontsize": 9, "fontweight": "bold"})
    ax.text(0, 0.06, f"{total_kg(records):g}", ha="center", va="center", fontsize=18, fontweight="bold", color=INK)
    ax.text(0, -0.14, "kg total", ha="center", va="center", fontsize=9, color=MUTED)
    ax.legend([f"{c['category']} ({c['pct']}%)" for c in rows], loc="center left", bbox_to_anchor=(0.98, 0.5),
              frameon=False, fontsize=8)
    ax.set_title("Share of total", loc="left", fontsize=12, fontweight="bold", color=INK, pad=10)


def _save(fig, path):
    fig.savefig(path, facecolor=fig.get_facecolor(), bbox_inches="tight")


def generate_all(records, out_dir: Path = EXPORT_DIR, goal: float = DRIVE_GOAL_KG) -> list[Path]:
    """Create the four PNG charts. Raises ChartError when impossible."""
    if not records:
        raise ChartError("There is no data to chart yet - add or import some entries first.")
    plt = _plt()
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    paths = []

    def single(name, draw, size=(8, 4.6)):
        fig, ax = plt.subplots(figsize=size, dpi=150)
        fig.patch.set_facecolor(BG)
        draw(ax)
        p = out_dir / f"chart_{name}_{stamp}.png"
        _save(fig, p)
        plt.close(fig)
        paths.append(p)

    single("categories", lambda ax: draw_bars(ax, records))
    single("trend", lambda ax: draw_trend(ax, records, goal), size=(9, 4.6))
    single("distribution", lambda ax: draw_donut(ax, records), size=(7, 4.6))

    pct, label, _ = goal_status(total_kg(records), goal)
    fig = plt.figure(figsize=(14, 8.2), dpi=130)
    fig.patch.set_facecolor(BG)
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1], hspace=0.42, wspace=0.28)
    draw_bars(fig.add_subplot(gs[0, 0]), records)
    draw_donut(fig.add_subplot(gs[0, 1]), records)
    draw_trend(fig.add_subplot(gs[1, :]), records, goal)
    fig.suptitle(f"{APP_NAME.title()}   |   {total_kg(records):g} kg of {goal:g} kg ({pct}%) - {label}",
                 x=0.06, ha="left", fontsize=15, fontweight="bold", color=INK, y=0.98)
    p = out_dir / f"chart_dashboard_{stamp}.png"
    _save(fig, p)
    plt.close(fig)
    paths.append(p)
    return paths
