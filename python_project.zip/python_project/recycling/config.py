"""Central configuration: paths, domain limits and drive targets."""
from datetime import date
from pathlib import Path

APP_NAME = "RECYCLING DRIVE DASHBOARD"
APP_TAGLINE = "Everyday Innovators  |  Project #47  |  Environment & Sustainability"
APP_OWNER = "Malla Reddy Vishwavidyapeeth - Technical Campus  |  CSE-AIDS"

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
EXPORT_DIR = BASE_DIR / "exports"
DATA_FILE = DATA_DIR / "records.json"
SAMPLE_JSON = DATA_DIR / "sample_recycling.json"
SAMPLE_CSV = DATA_DIR / "sample_recycling.csv"
SAMPLE_BAD_CSV = DATA_DIR / "sample_import_with_errors.csv"

SCHEMA_VERSION = 1

# --- Domain constraints -----------------------------------------------------
CATEGORIES = ("Paper", "Plastic", "Glass", "Metal", "Cardboard", "E-Waste", "Textile")

MIN_WEIGHT_KG = 0.1
MAX_WEIGHT_KG = 500.0
MAX_NAME_LEN = 40
MAX_NOTES_LEN = 120
MIN_DATE = date(2020, 1, 1)

# --- Drive targets & warning thresholds (edit freely) -----------------------
DRIVE_GOAL_KG = 1000.0            # total collection target
DRIVE_END_DATE = date(2026, 12, 15)  # drive deadline
ANOMALY_WEIGHT_KG = 150.0         # a single entry above this is flagged
CATEGORY_MIN_KG = 25.0            # categories below this total get a "low" warning
STALE_DAYS = 7                    # no new entries for this long -> warning
CRITICAL_STALE_DAYS = 14          # ... and this long -> critical

# --- Import safety -----------------------------------------------------------
MAX_IMPORT_ROWS = 10_000
MAX_IMPORT_BYTES = 5 * 1024 * 1024

PAGE_SIZE = 15
