"""Bulk CSV import with automatic format validation and a row-by-row error log."""
import csv
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from .config import EXPORT_DIR, MAX_IMPORT_BYTES, MAX_IMPORT_ROWS
from .models import dup_key
from .storage import RecordStore
from .validation import ValidationError, validate_record

REQUIRED_COLUMNS = ("date", "category", "weight_kg", "collector")
_HEADER_ALIASES = {"weight": "weight_kg", "kg": "weight_kg", "weight (kg)": "weight_kg",
                   "name": "collector", "note": "notes", "comment": "notes"}


class ImportFormatError(Exception):
    """The file as a whole cannot be imported (missing, too big, wrong columns...)."""


@dataclass
class ImportResult:
    imported: int = 0
    total_rows: int = 0
    errors: list[str] = field(default_factory=list)
    log_path: Path | None = None

    @property
    def rejected(self) -> int:
        return len(self.errors)


def import_csv(path, store: RecordStore, log_dir: Path = EXPORT_DIR) -> ImportResult:
    path = Path(str(path).strip().strip('"').strip("'")).expanduser()
    if not path.is_file():
        raise ImportFormatError(f"File not found: {path}")
    if path.suffix.lower() != ".csv":
        raise ImportFormatError("Only .csv files can be imported.")
    if path.stat().st_size > MAX_IMPORT_BYTES:
        raise ImportFormatError(f"File is larger than {MAX_IMPORT_BYTES // (1024 * 1024)} MB.")

    result = ImportResult()
    good_rows: list[dict] = []
    keys = store.existing_keys()

    try:
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                raise ImportFormatError("The file is empty (no header row).")
            reader.fieldnames = [_HEADER_ALIASES.get(h.strip().lower(), h.strip().lower())
                                 for h in reader.fieldnames if h is not None]
            missing = [c for c in REQUIRED_COLUMNS if c not in reader.fieldnames]
            if missing:
                raise ImportFormatError(f"Missing required column(s): {', '.join(missing)}. "
                                        f"Expected: {', '.join(REQUIRED_COLUMNS)}[, notes].")
            for row_no, row in enumerate(reader, start=2):  # header is line 1
                result.total_rows += 1
                if result.total_rows > MAX_IMPORT_ROWS:
                    raise ImportFormatError(f"Too many rows (limit {MAX_IMPORT_ROWS}).")
                if None in row:
                    result.errors.append(f"Row {row_no}: more columns than the header.")
                    continue
                try:
                    clean = validate_record(row)
                except ValidationError as exc:
                    result.errors.append(f"Row {row_no}: {exc}")
                    continue
                key = dup_key(clean["date"], clean["category"], clean["weight_kg"], clean["collector"])
                if key in keys:
                    result.errors.append(f"Row {row_no}: duplicate of an existing entry "
                                         f"({clean['date']}, {clean['category']}, {clean['weight_kg']:g} kg).")
                    continue
                keys.add(key)
                good_rows.append(clean)
    except UnicodeDecodeError:
        raise ImportFormatError("File is not valid UTF-8 text.") from None
    except csv.Error as exc:
        raise ImportFormatError(f"Malformed CSV: {exc}") from None

    result.imported = store.add_many(good_rows)
    if result.errors:
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        result.log_path = log_dir / f"import_errors_{stamp}.log"
        lines = [f"Import of {path.name} - {datetime.now().isoformat(timespec='seconds')}",
                 f"Rows read: {result.total_rows}  Imported: {result.imported}  Rejected: {result.rejected}", ""]
        result.log_path.write_text("\n".join(lines + result.errors) + "\n", encoding="utf-8")
    return result
