"""Data model."""
from dataclasses import asdict, dataclass
from datetime import date, datetime


@dataclass
class Record:
    id: int
    date: str          # ISO format YYYY-MM-DD
    category: str
    weight_kg: float
    collector: str
    notes: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def day(self) -> date:
        return datetime.strptime(self.date, "%Y-%m-%d").date()


def dup_key(day: str, category: str, weight_kg: float, collector: str) -> tuple:
    """Identity used to detect accidental duplicate entries."""
    return (day, category, round(float(weight_kg), 2), collector.strip().lower())
