"""Multi-format summary export: Markdown, plain-text audit log and standardised CSV."""
import csv
import hashlib
import json
from datetime import datetime
from pathlib import Path

from .analytics import find_warnings, summarize
from .config import APP_NAME, EXPORT_DIR


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _csv_safe(value):
    """Neutralise spreadsheet formula injection in text cells."""
    if isinstance(value, str) and value[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + value
    return value


def _md(text: str) -> str:
    return str(text).replace("|", "\\|")


def export_markdown(records, out_dir: Path = EXPORT_DIR, stamp: str | None = None) -> Path:
    s = summarize(records)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"recycling_report_{stamp or _stamp()}.md"
    L = [f"# {APP_NAME.title()} - Summary Report", "",
         f"_Generated {datetime.now().strftime('%Y-%m-%d %H:%M')}_", "",
         "## Headline", "",
         "| Metric | Value |", "|---|---|",
         f"| Total collected | {s['total_kg']:g} kg |",
         f"| Goal | {s['goal_kg']:g} kg ({s['goal_pct']}%) |",
         f"| Status | {s['status']} |",
         f"| Entries | {s['entries']} |",
         f"| Average per entry | {s['avg_per_entry']:g} kg |",
         f"| Average per active day | {s['avg_per_day']:g} kg |",
         f"| Period | {s['first_date'] or '-'} to {s['last_date'] or '-'} |",
         f"| 7-day trend | {s['trend']['direction']} "
         f"({'n/a' if s['trend']['change_pct'] is None else str(s['trend']['change_pct']) + '%'}) |",
         "", "## Totals by category", "",
         "| Category | Entries | Total (kg) | Average (kg) | Share |", "|---|---:|---:|---:|---:|"]
    L += [f"| {c['category']} | {c['count']} | {c['kg']:g} | {c['avg']:g} | {c['pct']}% |" for c in s["categories"]]
    L += ["", "## Top collectors", "", "| Collector | Entries | Total (kg) |", "|---|---:|---:|"]
    L += [f"| {_md(c['collector'])} | {c['count']} | {c['kg']:g} |" for c in s["collectors"][:5]]
    L += ["", "## Warnings", ""]
    L += [f"- **{w.level.upper()}**: {w.message}" for w in find_warnings(records)] or ["- None"]
    L += ["", "## All entries", "", "| ID | Date | Category | kg | Collector | Notes |", "|---:|---|---|---:|---|---|"]
    for r in sorted(records, key=lambda x: (x.date, x.id)):
        L.append(f"| {r.id} | {r.date} | {r.category} | {r.weight_kg:g} | {_md(r.collector)} | {_md(r.notes)} |")
    path.write_text("\n".join(L) + "\n", encoding="utf-8")
    return path


def export_text_audit(records, out_dir: Path = EXPORT_DIR, stamp: str | None = None) -> Path:
    s = summarize(records)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"recycling_audit_{stamp or _stamp()}.txt"
    canonical = json.dumps([r.to_dict() for r in sorted(records, key=lambda x: x.id)], sort_keys=True)
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    L = [f"{APP_NAME} - AUDIT LOG", "=" * 78,
         f"Generated : {datetime.now().isoformat(timespec='seconds')}",
         f"Entries   : {s['entries']}",
         f"Total     : {s['total_kg']:g} kg   Goal: {s['goal_kg']:g} kg ({s['goal_pct']}%)   Status: {s['status']}",
         f"SHA-256   : {digest}", "", "WARNINGS", "-" * 78]
    L += [f"[{w.level.upper():8}] {w.message}" for w in find_warnings(records)] or ["None"]
    L += ["", "TOTALS BY CATEGORY", "-" * 78]
    L += [f"{c['category']:<12}{c['count']:>5} entries{c['kg']:>10.2f} kg{c['pct']:>7.1f}%" for c in s["categories"]]
    L += ["", "ENTRIES", "-" * 78, f"{'ID':>4}  {'Date':<10}  {'Category':<10}  {'kg':>8}  {'Collector':<20}  Notes"]
    for r in sorted(records, key=lambda x: (x.date, x.id)):
        L.append(f"{r.id:>4}  {r.date:<10}  {r.category:<10}  {r.weight_kg:>8.2f}  {r.collector[:20]:<20}  {r.notes}")
    path.write_text("\n".join(L) + "\n", encoding="utf-8")
    return path


def export_csv(records, out_dir: Path = EXPORT_DIR, stamp: str | None = None) -> list[Path]:
    """Writes a category summary CSV and a full records CSV."""
    s = summarize(records)
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = stamp or _stamp()
    summary_path = out_dir / f"recycling_summary_{stamp}.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["category", "entries", "total_kg", "average_kg", "share_percent"])
        for c in s["categories"]:
            w.writerow([c["category"], c["count"], c["kg"], c["avg"], c["pct"]])
        w.writerow(["TOTAL", s["entries"], s["total_kg"], s["avg_per_entry"], 100.0 if s["entries"] else 0.0])
    records_path = out_dir / f"recycling_records_{stamp}.csv"
    with records_path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "date", "category", "weight_kg", "collector", "notes"])
        for r in sorted(records, key=lambda x: (x.date, x.id)):
            w.writerow([r.id, r.date, r.category, r.weight_kg, _csv_safe(r.collector), _csv_safe(r.notes)])
    return [summary_path, records_path]


def export_all(records, out_dir: Path = EXPORT_DIR) -> list[Path]:
    stamp = _stamp()
    return [export_markdown(records, out_dir, stamp), export_text_audit(records, out_dir, stamp),
            *export_csv(records, out_dir, stamp)]
