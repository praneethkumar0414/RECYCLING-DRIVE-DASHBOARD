"""JSON persistence with schema checks, atomic writes and corrupted-file recovery."""
import json
import os
from datetime import datetime
from pathlib import Path

from .config import DATA_FILE, SCHEMA_VERSION
from .models import Record, dup_key
from .validation import ValidationError, validate_record


class RecordStore:
    def __init__(self, path: Path | str = DATA_FILE):
        self.path = Path(path)
        self.records: list[Record] = []
        self.warnings: list[str] = []

    # ---- loading ---------------------------------------------------------
    def load(self) -> None:
        self.records, self.warnings = [], []
        if not self.path.exists():
            self.warnings.append("No data file found - created a fresh, empty one.")
            self.save()
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError, OSError) as exc:
            self._quarantine(f"unreadable ({type(exc).__name__})")
            return
        if not isinstance(data, dict) or not isinstance(data.get("records"), list):
            self._quarantine("unexpected structure")
            return

        seen_ids: set[int] = set()
        pending_no_id: list[dict] = []
        skipped = 0
        for index, raw in enumerate(data["records"], start=1):
            try:
                clean = validate_record(raw, allow_future=True)
            except ValidationError as exc:
                skipped += 1
                self.warnings.append(f"Skipped stored entry #{index}: {exc}")
                continue
            rid = raw.get("id")
            if isinstance(rid, int) and not isinstance(rid, bool) and rid > 0 and rid not in seen_ids:
                seen_ids.add(rid)
                self.records.append(Record(id=rid, **clean))
            else:
                pending_no_id.append(clean)
        for clean in pending_no_id:  # missing/duplicate ids get fresh ones
            rid = self._next_id()
            self.records.append(Record(id=rid, **clean))
        if skipped or pending_no_id:
            self.save()

    def _quarantine(self, reason: str) -> None:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = self.path.with_name(f"{self.path.stem}.corrupt-{stamp}{self.path.suffix}")
        try:
            os.replace(self.path, backup)
            note = f"Data file was {reason}; the original was kept as '{backup.name}'."
        except OSError:
            note = f"Data file was {reason} and could not be backed up."
        self.warnings.append(note + " Started with a clean file.")
        self.records = []
        self.save()

    # ---- saving ----------------------------------------------------------
    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "schema_version": SCHEMA_VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "records": [r.to_dict() for r in self.records],
        }
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.path)  # atomic: never leaves a half-written file

    # ---- mutations -------------------------------------------------------
    def _next_id(self) -> int:
        return max((r.id for r in self.records), default=0) + 1

    def add(self, day: str, category: str, weight_kg: float, collector: str, notes: str = "") -> Record:
        rec = Record(self._next_id(), day, category, weight_kg, collector, notes)
        self.records.append(rec)
        self.save()
        return rec

    def add_many(self, rows: list[dict]) -> int:
        for row in rows:
            self.records.append(Record(self._next_id(), **row))
        if rows:
            self.save()
        return len(rows)

    def delete(self, rec_id: int) -> Record | None:
        for i, rec in enumerate(self.records):
            if rec.id == rec_id:
                removed = self.records.pop(i)
                self.save()
                return removed
        return None

    def get(self, rec_id: int) -> Record | None:
        return next((r for r in self.records if r.id == rec_id), None)

    def existing_keys(self) -> set[tuple]:
        return {dup_key(r.date, r.category, r.weight_kg, r.collector) for r in self.records}

    def load_sample(self, sample_path: Path | str, replace: bool = False) -> int:
        """Load the bundled JSON sample. Returns how many entries were added."""
        data = json.loads(Path(sample_path).read_text(encoding="utf-8"))
        if replace:
            self.records = []
        keys = self.existing_keys()
        rows = []
        for raw in data["records"]:
            clean = validate_record(raw, allow_future=True)
            key = dup_key(clean["date"], clean["category"], clean["weight_kg"], clean["collector"])
            if key not in keys:
                keys.add(key)
                rows.append(clean)
        added = self.add_many(rows)
        if replace and not rows:
            self.save()
        return added
