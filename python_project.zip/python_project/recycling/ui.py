"""Terminal helpers: ANSI styling, fixed-width tables, pagination and validated prompts."""
import os
import subprocess
import sys

from .config import APP_NAME, APP_OWNER, APP_TAGLINE, CATEGORIES, PAGE_SIZE
from .validation import ValidationError

USE_COLOR = True

RESET = "\033[0m"
CODES = {
    "bold": "\033[1m", "dim": "\033[2m",
    "purple": "\033[38;5;99m", "lavender": "\033[38;5;183m",
    "green": "\033[38;5;114m", "yellow": "\033[38;5;221m", "red": "\033[38;5;203m",
}


def setup_terminal(no_color: bool = False) -> None:
    """Enable UTF-8 output, ANSI on Windows, and decide whether to colour."""
    global USE_COLOR
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    USE_COLOR = sys.stdout.isatty() and not no_color and "NO_COLOR" not in os.environ
    if USE_COLOR and os.name == "nt":
        os.system("")  # switches on ANSI escape handling in Windows consoles


def paint(text, *styles) -> str:
    if not USE_COLOR or not styles:
        return str(text)
    return "".join(CODES[s] for s in styles) + str(text) + RESET


def ok(msg):    print(paint("  + " + msg, "green"))
def warn(msg):  print(paint("  ! " + msg, "yellow"))
def err(msg):   print(paint("  x " + msg, "red"))
def info(msg):  print(paint("  " + msg, "lavender"))


LEVEL_STYLE = {"critical": "red", "warning": "yellow", "info": "lavender", "ok": "green", "warn": "yellow", "bad": "red"}


def heading(title: str) -> None:
    print()
    print(paint(f"  {title}", "bold", "purple"))
    print(paint("  " + "-" * max(len(title), 40), "purple"))


def banner() -> None:
    width = 66
    line = "=" * width
    print()
    print(paint(line, "purple"))
    print(paint(f"  {APP_NAME}".ljust(width), "bold", "lavender"))
    print(paint(f"  {APP_TAGLINE}", "dim"))
    print(paint(f"  {APP_OWNER}", "dim"))
    print(paint(line, "purple"))


def bar(value: float, maximum: float, width: int = 24) -> str:
    filled = 0 if maximum <= 0 else round(width * value / maximum)
    return "#" * filled + "." * (width - filled)


def progress_bar(pct: float, width: int = 30) -> str:
    filled = max(0, min(width, round(width * pct / 100)))
    return "[" + "#" * filled + "-" * (width - filled) + f"] {pct:g}%"


# ---- tables ------------------------------------------------------------------
def _cell(text, width, align):
    text = str(text)
    if len(text) > width:
        text = text[: max(width - 1, 1)] + "~"
    return text.rjust(width) if align == ">" else text.ljust(width)


def format_table(headers, rows, widths, aligns=None) -> list[str]:
    aligns = aligns or ["<"] * len(headers)
    head = " | ".join(_cell(h, w, a) for h, w, a in zip(headers, widths, aligns))
    sep = "-+-".join("-" * w for w in widths)
    body = [" | ".join(_cell(c, w, a) for c, w, a in zip(row, widths, aligns)) for row in rows]
    return ["  " + head, "  " + sep] + ["  " + b for b in body]


def print_table(headers, rows, widths, aligns=None, page_size: int = PAGE_SIZE) -> None:
    """Print a table, pausing every `page_size` rows."""
    lines = format_table(headers, rows, widths, aligns)
    head, body = lines[:2], lines[2:]
    if not body:
        info("(no rows)")
        return
    for start in range(0, len(body), page_size):
        print(paint(head[0], "bold", "lavender"))
        print(paint(head[1], "purple"))
        for line in body[start:start + page_size]:
            print(line)
        shown = min(start + page_size, len(body))
        if shown < len(body):
            try:
                answer = input(paint(f"  -- {shown}/{len(body)} shown - Enter for next page, q to stop: ", "dim"))
            except EOFError:
                return
            if answer.strip().lower() == "q":
                return
        else:
            print(paint(f"  {len(body)} row(s)", "dim"))


# ---- prompts ---------------------------------------------------------------------
class Cancelled(Exception):
    """User typed :q to abandon the current action."""


def ask(prompt: str, validator, default=None):
    """Loop until `validator(raw)` accepts the input. Type :q to cancel."""
    suffix = f" [{default}]" if default not in (None, "") else ""
    while True:
        raw = input(paint(f"  {prompt}{suffix}: ", "lavender")).strip()
        if raw.lower() == ":q":
            raise Cancelled
        if raw == "" and default is not None:
            raw = str(default)
        try:
            return validator(raw)
        except ValidationError as exc:
            err(str(exc))


def ask_category(validator) -> str:
    for i, name in enumerate(CATEGORIES, start=1):
        print(f"    {paint(i, 'purple')}. {name}")

    def pick(raw):
        if raw.isdigit() and 1 <= int(raw) <= len(CATEGORIES):
            return CATEGORIES[int(raw) - 1]
        return validator(raw)
    return ask("Category (number or name)", pick)


def confirm(prompt: str, default: bool = False) -> bool:
    hint = "Y/n" if default else "y/N"
    while True:
        raw = input(paint(f"  {prompt} ({hint}): ", "yellow")).strip().lower()
        if raw == "":
            return default
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        err("Please answer y or n.")


def pause() -> None:
    try:
        input(paint("\n  Press Enter to return to the menu...", "dim"))
    except EOFError:
        pass


def open_file(path) -> bool:
    """Best-effort: open a file in the default viewer. Returns False if not possible."""
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=False)
        else:
            subprocess.run(["xdg-open", str(path)], check=False,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except (OSError, AttributeError):
        return False
