"""Defensive input validation. Every validator returns a clean value or raises ValidationError."""
import math
import re
from datetime import date, datetime

from .config import (
    CATEGORIES, MAX_NAME_LEN, MAX_NOTES_LEN, MAX_WEIGHT_KG, MIN_DATE, MIN_WEIGHT_KG,
)


class ValidationError(ValueError):
    """Raised with a user-friendly message when an input is not acceptable."""


DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y")

_CATEGORY_MAP = {c.lower(): c for c in CATEGORIES}
_CATEGORY_MAP.update({
    "ewaste": "E-Waste", "e waste": "E-Waste", "electronics": "E-Waste",
    "textiles": "Textile", "clothes": "Textile", "cloth": "Textile",
    "plastics": "Plastic", "papers": "Paper", "metals": "Metal",
})

_NAME_RE = re.compile(r"^\w[\w .,'&\-]{1,%d}$" % (MAX_NAME_LEN - 1))
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")


def validate_date(value, allow_future: bool = False, today: date | None = None) -> str:
    text = str(value if value is not None else "").strip()
    if not text:
        raise ValidationError("Date cannot be blank. Use YYYY-MM-DD, e.g. 2026-11-23.")
    parsed = None
    for fmt in DATE_FORMATS:
        try:
            parsed = datetime.strptime(text, fmt).date()
            break
        except ValueError:
            continue
    if parsed is None:
        raise ValidationError(f"'{text}' is not a valid date. Use YYYY-MM-DD, e.g. 2026-11-23.")
    today = today or date.today()
    if parsed < MIN_DATE:
        raise ValidationError(f"Date is too old (earliest allowed: {MIN_DATE.isoformat()}).")
    if not allow_future and parsed > today:
        raise ValidationError(f"Date {parsed.isoformat()} is in the future (today is {today.isoformat()}).")
    return parsed.isoformat()


def validate_category(value) -> str:
    key = " ".join(str(value if value is not None else "").strip().lower().split())
    if not key:
        raise ValidationError("Category cannot be blank.")
    if key in _CATEGORY_MAP:
        return _CATEGORY_MAP[key]
    raise ValidationError(f"Unknown category '{key}'. Choose one of: {', '.join(CATEGORIES)}.")


def validate_weight(value) -> float:
    if isinstance(value, bool):
        raise ValidationError("Weight must be a number.")
    if isinstance(value, (int, float)):
        number = float(value)
    else:
        text = str(value if value is not None else "").strip().lower()
        if text.endswith("kg"):
            text = text[:-2].strip()
        if not text:
            raise ValidationError("Weight cannot be blank.")
        try:
            number = float(text)
        except ValueError:
            raise ValidationError(f"'{text}' is not a number. Enter weight in kg, e.g. 12.5.") from None
    if math.isnan(number) or math.isinf(number):
        raise ValidationError("Weight must be a finite number.")
    if number < MIN_WEIGHT_KG or number > MAX_WEIGHT_KG:
        raise ValidationError(f"Weight must be between {MIN_WEIGHT_KG} and {MAX_WEIGHT_KG:g} kg (got {number:g}).")
    return round(number, 2)


def validate_collector(value) -> str:
    text = " ".join(str(value if value is not None else "").split())
    if not text:
        raise ValidationError("Collector name cannot be blank.")
    if not _NAME_RE.match(text):
        raise ValidationError(
            f"Collector must be 2-{MAX_NAME_LEN} characters: letters, digits, spaces and . , ' & - only."
        )
    return text


def validate_notes(value) -> str:
    text = _CONTROL_RE.sub(" ", str(value if value is not None else "")).strip()
    text = " ".join(text.split())
    if len(text) > MAX_NOTES_LEN:
        raise ValidationError(f"Notes are too long ({len(text)} chars, max {MAX_NOTES_LEN}).")
    return text


def validate_id(value) -> int:
    text = str(value if value is not None else "").strip().lstrip("#")
    if not text.isdigit() or int(text) < 1:
        raise ValidationError("ID must be a positive whole number.")
    return int(text)


def validate_record(raw: dict, allow_future: bool = False, today: date | None = None) -> dict:
    """Validate one raw mapping (from CSV/JSON/UI) and return normalised fields (without id)."""
    if not isinstance(raw, dict):
        raise ValidationError("Record is not an object/row.")
    for field in ("date", "category", "weight_kg", "collector"):
        if raw.get(field) is None or str(raw.get(field)).strip() == "":
            raise ValidationError(f"Missing value for '{field}'.")
    return {
        "date": validate_date(raw["date"], allow_future=allow_future, today=today),
        "category": validate_category(raw["category"]),
        "weight_kg": validate_weight(raw["weight_kg"]),
        "collector": validate_collector(raw["collector"]),
        "notes": validate_notes(raw.get("notes", "")),
    }
