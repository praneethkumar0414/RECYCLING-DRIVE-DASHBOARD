import csv
import json
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from recycling import analytics, importer, reports, validation as v  # noqa: E402
from recycling.config import SAMPLE_BAD_CSV, SAMPLE_JSON  # noqa: E402
from recycling.models import Record  # noqa: E402
from recycling.storage import RecordStore  # noqa: E402


class ValidationTests(unittest.TestCase):
    def test_weight_accepts_and_rounds(self):
        self.assertEqual(v.validate_weight("12.345"), 12.35 if round(12.345, 2) == 12.35 else 12.34)
        self.assertEqual(v.validate_weight("7 kg"), 7.0)
        self.assertEqual(v.validate_weight("0.1"), 0.1)
        self.assertEqual(v.validate_weight("500"), 500.0)

    def test_weight_rejects_bad_values(self):
        for bad in ["", "abc", "-1", "0", "0.09", "500.01", "nan", "inf", "1,5", None, True]:
            with self.assertRaises(v.ValidationError, msg=repr(bad)):
                v.validate_weight(bad)

    def test_date_formats_and_future(self):
        today = date(2026, 11, 23)
        self.assertEqual(v.validate_date("23-11-2026", today=today), "2026-11-23")
        self.assertEqual(v.validate_date("2026-11-23", today=today), "2026-11-23")
        for bad in ["", "2026-13-01", "yesterday", "2026-11-24", "2019-01-01"]:
            with self.assertRaises(v.ValidationError, msg=bad):
                v.validate_date(bad, today=today)
        self.assertEqual(v.validate_date("2026-11-24", allow_future=True, today=today), "2026-11-24")

    def test_category_aliases(self):
        self.assertEqual(v.validate_category("  e waste "), "E-Waste")
        self.assertEqual(v.validate_category("PAPER"), "Paper")
        with self.assertRaises(v.ValidationError):
            v.validate_category("lava")

    def test_collector_and_notes(self):
        self.assertEqual(v.validate_collector("  Zoë   D'Souza "), "Zoë D'Souza")
        for bad in ["", "A", "<script>", "x" * 41]:
            with self.assertRaises(v.ValidationError):
                v.validate_collector(bad)
        self.assertEqual(v.validate_notes("a\nb\x00c"), "a b c")
        with self.assertRaises(v.ValidationError):
            v.validate_notes("x" * 121)

    def test_id(self):
        self.assertEqual(v.validate_id("#12"), 12)
        for bad in ["0", "-3", "x", ""]:
            with self.assertRaises(v.ValidationError):
                v.validate_id(bad)


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "records.json"

    def tearDown(self):
        self.tmp.cleanup()

    def test_missing_file_creates_template(self):
        s = RecordStore(self.path)
        s.load()
        self.assertTrue(self.path.exists())
        self.assertEqual(s.records, [])
        self.assertTrue(s.warnings)

    def test_corrupt_file_is_quarantined(self):
        self.path.write_text("{ not json", encoding="utf-8")
        s = RecordStore(self.path)
        s.load()
        self.assertEqual(s.records, [])
        self.assertEqual(len(list(Path(self.tmp.name).glob("records.corrupt-*.json"))), 1)
        self.assertEqual(json.loads(self.path.read_text())["records"], [])

    def test_wrong_structure_is_quarantined(self):
        self.path.write_text("[1, 2, 3]", encoding="utf-8")
        s = RecordStore(self.path)
        s.load()
        self.assertEqual(s.records, [])
        self.assertTrue(any("kept as" in w for w in s.warnings))

    def test_persistence_round_trip_and_bad_entry_skipped(self):
        s = RecordStore(self.path)
        s.load()
        s.add("2026-11-01", "Paper", 10.0, "Eco Club", "hi")
        s.add("2026-11-02", "Glass", 5.5, "Eco Club")
        data = json.loads(self.path.read_text())
        data["records"].append({"id": 99, "date": "bad", "category": "Paper", "weight_kg": 1, "collector": "X Y"})
        self.path.write_text(json.dumps(data), encoding="utf-8")
        s2 = RecordStore(self.path)
        s2.load()
        self.assertEqual([r.id for r in s2.records], [1, 2])
        self.assertTrue(any("Skipped" in w for w in s2.warnings))

    def test_delete_and_ids(self):
        s = RecordStore(self.path)
        s.load()
        a = s.add("2026-11-01", "Paper", 10, "Eco Club")
        b = s.add("2026-11-02", "Paper", 11, "Eco Club")
        self.assertIsNone(s.delete(999))
        self.assertEqual(s.delete(a.id).id, a.id)
        c = s.add("2026-11-03", "Paper", 12, "Eco Club")
        self.assertEqual(c.id, b.id + 1)

    def test_sample_loads_and_merge_skips_duplicates(self):
        s = RecordStore(self.path)
        s.load()
        added = s.load_sample(SAMPLE_JSON)
        self.assertGreaterEqual(added, 30)
        self.assertEqual(s.load_sample(SAMPLE_JSON), 0)


def rec(i, day, cat, kg, who="Eco Club"):
    return Record(i, day, cat, kg, who, "")


class AnalyticsTests(unittest.TestCase):
    def test_totals_and_categories(self):
        rs = [rec(1, "2026-11-01", "Paper", 10), rec(2, "2026-11-01", "Glass", 5), rec(3, "2026-11-02", "Paper", 5)]
        self.assertEqual(analytics.total_kg(rs), 20)
        cats = {c["category"]: c for c in analytics.by_category(rs)}
        self.assertEqual(cats["Paper"]["kg"], 15)
        self.assertEqual(cats["Paper"]["pct"], 75.0)
        self.assertEqual(cats["Metal"]["kg"], 0)
        self.assertEqual(analytics.cumulative(analytics.daily_totals(rs)), [15, 20])

    def test_goal_status(self):
        self.assertEqual(analytics.goal_status(1000, 1000)[1], "GOAL REACHED")
        self.assertEqual(analytics.goal_status(600, 1000)[1], "ON TRACK")
        self.assertEqual(analytics.goal_status(300, 1000)[1], "BEHIND TARGET")
        self.assertTrue(analytics.goal_status(10, 1000)[1].startswith("CRITICAL"))

    def test_trend(self):
        rs = [rec(1, "2026-11-01", "Paper", 10), rec(2, "2026-11-10", "Paper", 30)]
        t = analytics.weekly_trend(rs)
        self.assertEqual((t["last7"], t["prev7"], t["direction"]), (30, 10, "rising"))
        self.assertEqual(analytics.weekly_trend([])["direction"], "no data")

    def test_search(self):
        rs = [rec(1, "2026-11-01", "Paper", 10, "Eco Club"), rec(2, "2026-11-05", "Glass", 80, "Class 10A")]
        self.assertEqual(len(analytics.search(rs, keyword="class")), 1)
        self.assertEqual(len(analytics.search(rs, category="Paper")), 1)
        self.assertEqual(len(analytics.search(rs, date_from="2026-11-02")), 1)
        self.assertEqual(len(analytics.search(rs, min_weight=50)), 1)

    def test_warnings(self):
        rs = [rec(1, "2026-10-01", "Paper", 200), rec(2, "2026-10-01", "Paper", 200)]
        msgs = [w.message for w in analytics.find_warnings(rs, today=date(2026, 12, 20))]
        text = " ".join(msgs)
        self.assertIn("Anomalous", text)
        self.assertIn("duplicate", text.lower())
        self.assertIn("deadline", text.lower())
        levels = [w.level for w in analytics.find_warnings(rs, today=date(2026, 12, 20))]
        self.assertEqual(levels[0], "critical")
        self.assertEqual(analytics.find_warnings([])[0].level, "info")


class ImportAndReportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.store = RecordStore(self.dir / "r.json")
        self.store.load()

    def tearDown(self):
        self.tmp.cleanup()

    def test_import_reports_row_errors(self):
        result = importer.import_csv(SAMPLE_BAD_CSV, self.store, log_dir=self.dir)
        self.assertEqual(result.imported, 5)
        self.assertEqual(result.rejected, 9)
        self.assertTrue(any("Row 3" in e for e in result.errors))
        self.assertTrue(any("duplicate" in e for e in result.errors))
        self.assertTrue(result.log_path.exists())
        self.assertEqual(len(self.store.records), 5)

    def test_import_format_errors(self):
        for name, body in [("a.csv", ""), ("b.csv", "date,category\n2026-11-01,Paper\n")]:
            p = self.dir / name
            p.write_text(body, encoding="utf-8")
            with self.assertRaises(importer.ImportFormatError):
                importer.import_csv(p, self.store, log_dir=self.dir)
        with self.assertRaises(importer.ImportFormatError):
            importer.import_csv(self.dir / "missing.csv", self.store, log_dir=self.dir)
        txt = self.dir / "x.txt"
        txt.write_text("hi")
        with self.assertRaises(importer.ImportFormatError):
            importer.import_csv(txt, self.store, log_dir=self.dir)

    def test_exports(self):
        self.store.load_sample(SAMPLE_JSON)
        self.store.add("2026-11-22", "Paper", 3, "Eco Club", "=HYPERLINK(\"x\")")
        paths = reports.export_all(self.store.records, out_dir=self.dir / "out")
        self.assertEqual(len(paths), 4)
        self.assertTrue(all(p.stat().st_size > 0 for p in paths))
        md = next(p for p in paths if p.suffix == ".md").read_text(encoding="utf-8")
        self.assertIn("Totals by category", md)
        audit = next(p for p in paths if p.suffix == ".txt").read_text(encoding="utf-8")
        self.assertIn("SHA-256", audit)
        records_csv = next(p for p in paths if "records" in p.name)
        with records_csv.open(newline="", encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        self.assertTrue(any(r["notes"].startswith("'=") for r in rows))  # formula neutralised


class ChartTests(unittest.TestCase):
    def test_charts_created(self):
        try:
            import matplotlib  # noqa: F401
        except ImportError:
            self.skipTest("matplotlib not installed")
        from recycling import charts
        with tempfile.TemporaryDirectory() as tmp:
            s = RecordStore(Path(tmp) / "r.json")
            s.load()
            s.load_sample(SAMPLE_JSON)
            paths = charts.generate_all(s.records, out_dir=Path(tmp) / "c")
            self.assertEqual(len(paths), 4)
            self.assertTrue(all(p.stat().st_size > 5000 for p in paths))
            with self.assertRaises(charts.ChartError):
                charts.generate_all([], out_dir=Path(tmp) / "c")


if __name__ == "__main__":
    unittest.main()
